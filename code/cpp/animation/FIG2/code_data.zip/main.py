from manim import *
from scipy.spatial.transform import Rotation
from scipy.interpolate import PchipInterpolator
import numpy as np
import math as m
import simutils as su

data = su.extract()
t = data["australia"].t

datasets = [
    {"name": "C", "x": data["australia"].x, "y": data["australia"].y, "z": data["australia"].z,
     "mu_x": data["australia"].mu_x, "mu_y": data["australia"].mu_y, "mu_z": data["australia"].mu_z, "color": RED},
    {"name": "H", "x": data["hamburg"].x, "y": data["hamburg"].y, "z": data["hamburg"].z,
     "mu_x": data["hamburg"].mu_x, "mu_y": data["hamburg"].mu_y, "mu_z": data["hamburg"].mu_z, "color": BLUE},
    {"name": "J", "x": data["jakarta"].x, "y": data["jakarta"].y, "z": data["jakarta"].z,
     "mu_x": data["jakarta"].mu_x, "mu_y": data["jakarta"].mu_y, "mu_z": data["jakarta"].mu_z, "color": YELLOW},
    {"name": "T", "x": data["tokyo"].x, "y": data["tokyo"].y, "z": data["tokyo"].z,
     "mu_x": data["tokyo"].mu_x, "mu_y": data["tokyo"].mu_y, "mu_z": data["tokyo"].mu_z, "color": GREEN},
]

SCALE = 50
SLOPE = np.tan(np.deg2rad(20))
RADIUS = 0.005
NORMAL = np.array([0, -SLOPE, 1]) / np.linalg.norm([0, -SLOPE, 1])
mu_display_scale = 0.02

# --- parameters ---
EXPORT_STILL = False          # True = render one frame only
EXPORT_TIME = 3.3 * t[-1] / 4   # still-frame time, e.g. 3/4 of the simulation
MU_TRAIL_DURATION = 1.5       # seconds, e.g. 10s sim -> trail fades after about 2s
SHOW_TIME_TRACKER = True

for d in datasets:
    d["x_s"] = PchipInterpolator(t, d["x"])
    d["y_s"] = PchipInterpolator(t, d["y"])
    d["z_s"] = PchipInterpolator(t, d["z"])
    d["mx_s"] = PchipInterpolator(t, d["mu_x"])
    d["my_s"] = PchipInterpolator(t, d["mu_y"])
    d["mz_s"] = PchipInterpolator(t, d["mu_z"])

def quat_mat(q0, q1, q2, q3):
    return Rotation.from_quat([q1, q2, q3, q0]).as_matrix()

def state_at(sim_time, d):
    tt = np.clip(sim_time, t[0], t[-1])

    x = d["x_s"](tt)
    y = d["y_s"](tt)
    pos = np.array([x, y, SLOPE * y]) + RADIUS * NORMAL

    mu_body = np.array([d["mx_s"](tt), d["my_s"](tt), d["mz_s"](tt)])
    return pos, mu_body

class Anim(ThreeDScene):
    def construct(self):
        time = ValueTracker(EXPORT_TIME if EXPORT_STILL else t[0])

        # static scene center, computed once from the chosen reference frame
        frame_t = EXPORT_TIME if EXPORT_STILL else t[round(3 * (len(t) / 4))]
        all_points = np.array([state_at(frame_t, d)[0] for d in datasets])
        scene_center = SCALE * all_points.mean(axis=0)

        def world_pos(com):
            return SCALE * com - scene_center

        self.set_camera_orientation(
            phi=60 * DEGREES,
            theta=-45 * DEGREES,
            zoom=0.20, #0.2
        )

        balls = VGroup()
        labels = VGroup()
        trails = VGroup()
        mu_arrows = VGroup()
        mu_trails = VGroup()

        surface = Surface(
            lambda u, v: np.array([u, v, v * np.tan(np.deg2rad(20))]) * SCALE - scene_center,
            u_range=[-0.08, 0.08],
            v_range=[-0.6, 0.01],
            resolution=15,
            fill_opacity=0.5,
        )

        for d in datasets:
            ball = Sphere(
                radius=SCALE * RADIUS,
                resolution=(50, 50),
                fill_opacity=1.0,
                stroke_width=0,
            ).set_color(d["color"])

            ball.add_updater(
                lambda m, d=d: m.move_to(world_pos(state_at(time.get_value(), d)[0]))
            )

            label = always_redraw(
                lambda d=d, b=ball: (
                    Text(d["name"], font_size=5, color=BLACK)
                    .next_to(b, LEFT, buff=0.30)
                    .add_background_rectangle(color=WHITE, opacity=0.5, buff=0.01)
                )
            )
            self.add_fixed_orientation_mobjects(label)
            self.add_foreground_mobjects(label)

            trail = TracedPath(
                ball.get_center,
                stroke_width=2,
                stroke_color=d["color"],
                dissipating_time=None,
            )

            def make_mu_arrow(d=d):
                com, mu_body = state_at(time.get_value(), d)
                n = np.linalg.norm(mu_body)
                if n < 1e-8:
                    mu_body = np.array([0, 0, 1.0])
                    n = 1.0
                start = world_pos(com)
                end = start + SCALE * mu_display_scale * mu_body / n
                return Arrow3D(
                    start=start,
                    end=end,
                    resolution=30,
                    color=d["color"],
                )

            mu_arrow = always_redraw(make_mu_arrow)

            balls.add(ball)
            labels.add(label)
            trails.add(trail)
            mu_arrows.add(mu_arrow)

            # omit mu trails entirely in still-frame mode
            if not EXPORT_STILL:
                mu_trail = TracedPath(
                    mu_arrow.get_end,
                    stroke_width=1,
                    stroke_color=d["color"],
                    dissipating_time=MU_TRAIL_DURATION,
                )
                mu_trails.add(mu_trail)


        self.add(surface, balls, labels, trails, mu_arrows)
        if not EXPORT_STILL:
            self.add(mu_trails)

        # simulation-time tracker in the top-left corner
        if SHOW_TIME_TRACKER:
            time_label = VGroup(
                Text("t =", font_size=26, color=BLACK),
                DecimalNumber(
                    time.get_value(),
                    num_decimal_places=2,
                    font_size=26,
                    color=BLACK,
                ),
            ).arrange(RIGHT, buff=0.12)
            time_label.add_background_rectangle(color=WHITE, opacity=0.75, buff=0.08)
            time_label.to_corner(UL, buff=0.25)
            self.add_fixed_in_frame_mobjects(time_label)

            def update_time_label(mob):
                mob[1].set_value(time.get_value())

            time_label.add_updater(update_time_label)

        if EXPORT_STILL:
            self.wait(0.1)
        else:
            self.play(time.animate.set_value(t[-1]), run_time=10, rate_func=linear)